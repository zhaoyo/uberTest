sap.ui.define([
	"sap/ui/base/Object"
	], function(Object){
		"use strict";
		
		return Object.extend("zuber.controller.RideRequest", {
			constructor: function(oView){
				this._oView = oView;
			},
			
			init: function(){
				
			}
		});
	});