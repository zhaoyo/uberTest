sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast"
], function(Controller, MessageToast) {
	"use strict";

	return Controller.extend("sap.bao.fs.xc.uber.controller.Main", {
		onInit: function(){
			this.SERVER_TOKEN = "UE_bVP3MoyBFfvss1XUILp73S8JiBpAAgnfzPVsL";
			this.CLIENT_ID = "s_xBlSVfKCEMGQ_XDQFK9mX-kVxlJCd2";
			this.CLIENT_SECRET = "meR38AbS2WpivBvmT2N8Zsq9hz9y9yjOszJj65Q5";
			// this.ACCESS_TOKEN = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzY29wZXMiOlsicmVxdWVzdCIsInByb2ZpbGUiLCJoaXN0b3J5Il0sInN1YiI6IjRiOTY4ZmNmLWI2OGQtNDQ0Ni04NDFkLTcwOGUyNTVjOTFjNCIsImlzcyI6InViZXItdXMxIiwianRpIjoiMjE3YWMyMTMtYzc0Ni00NmEzLWI4MzYtMGY2YWZmYzBjOGU2IiwiZXhwIjoxNDk0MDUyMDEyLCJpYXQiOjE0OTE0NjAwMTIsInVhY3QiOiJ5VzFTSXRsNmVJWmNSVUN2bndYMkxsY2lsSjFYTVciLCJuYmYiOjE0OTE0NTk5MjIsImF1ZCI6InNfeEJsU1ZmS0NFTUdRX1hEUUZLOW1YLWtWeGxKQ2QyIn0.JKkUkEJ3n9f6SdH3ayD58DMyyzq21tVHfJQJnzvCE6mWn6PO8nlF_w_6XgGzGp20rC9Iv3gWWgDXLojraMXrxm-O-jIa9DO3YBgl6xFs-yzFcSdUML_5yggASa8Rmkz5n19kNafczN4200vEeQgb8OQUSEHcoXaSgEa2DBW35jtWvCPad-ka_id2TviR7_aeGaHV3EtURh76uEqtNOhj_m14rMuZLR-hpcU0eEB0My4nr_p7rZGMo2OM-yGjQU-nE44TsW7nsIzAQYb0taqhiWBS4cAk98UuyzF7v7ZrvMGuYXkgDyqnvDkEwn428zS7sCxk5obVqVCCwgqsU4H0XQ";
			this.ACCESS_TOKEN = "KA.eyJ2ZXJzaW9uIjoyLCJpZCI6Ii9JKzNaSnJKUzlTQUFOSjFteW1pNFE9PSIsImV4cGlyZXNfYXQiOjE1MTU3NDI0OTcsInBpcGVsaW5lX2tleV9pZCI6Ik1RPT0iLCJwaXBlbGluZV9pZCI6MX0.SbVtBZSD8l7h_SSvB1nxXgXxEGUUDLRVcIZoF9ynAko";
			this.oSampleRequest = {
				"sourceLat": "37.7752315",
				"sourceLng": "-122.418075",
				"destinationLat": "37.7752415",
				"destinationLng": "-122.518075",
				"seat_count": "2"
			};
			this.oSampleProduct = {
				"sourceLat": "37.7752315",
				"sourceLng": "-122.418075",
				"destinationLat": "37.7899886",
				"destinationLng": "-122.4021253",
				"seat_count": "2"
			};
			
			this.oDialogRequest = sap.ui.xmlfragment("dialogRequest", "sap.bao.fs.xc.uber.view.RideRequest", this.getView().getController());
			this.oDialogStatus = sap.ui.xmlfragment("dialogStatus", "sap.bao.fs.xc.uber.view.RideStatus", this.getView().getController());
			
			var meModel = new sap.ui.model.json.JSONModel({
				"data": {}
			});
			
			var productModel = new sap.ui.model.json.JSONModel({
				"data": {}
			});
			
			var priceModel = new sap.ui.model.json.JSONModel({
				"data": {}
			});
			
			var estimateModel = new sap.ui.model.json.JSONModel({
				"data": {}
			});
			
			var statusModel = new sap.ui.model.json.JSONModel({
				"data": {}
			});
			
			this.getView().setModel(meModel, "profile");
			this.getView().setModel(productModel, "product");
			this.getView().setModel(priceModel, "prices");
			this.getView().setModel(estimateModel, "estimate");
			this.getView().setModel(statusModel, "rideStatus");
			
			this.getMe();
			this.getProducts();
			this.getPrices();
		},
		
		// get uber application data
		getMe: function(){
			var sUrl = "https://api.uber.com/v1.2/me";
			var oModel = this.getView().getModel("profile");
			var personalToken = "KA.eyJ2ZXJzaW9uIjoyLCJpZCI6InZCNXlwSjBjUjNpaDJWMEo5bTJ1NEE9PSIsImV4cGlyZXNfYXQiOjE0OTc1ODY4MjUsInBpcGVsaW5lX2tleV9pZCI6Ik1RPT0iLCJwaXBlbGluZV9pZCI6MX0.3mrOkvweoD1UZ77c_x5oZxJngZRyrhoomo3byrg3Xto";
			
			// call uber api 
			$.ajax({
				url: sUrl,
				type: "get",
				async: true,
				headers: {
					"Authorization": "Bearer " + this.ACCESS_TOKEN,
					"Content-Type": "application/json"
				}
			}).done(function(results){
				$.sap.log.info(results);
				oModel.setProperty("/data", results);
			}).fail(function(xhr, textStatus, errorThrown){
				MessageToast.show("Get Uber User Error");
				$.sap.log.error(xhr);
			});
		},
		
		// get available ride types 
		getProducts: function(){
			var oData = {
				"sourceLat": "37.7752315",
				"sourceLng": "-122.418075",
				"destinationLat": "37.7899886",
				"destinationLng": "-122.4021253",
				"seat_count": "2"
			};
			var sUrl = "https://api.uber.com/v1.2/products?latitude=" + oData.sourceLat + "&longitude=" + oData.sourceLng;
			var oModel = this.getView().getModel("product");
			
			// call uber api to get available products
			$.ajax({
				url: sUrl,
				type: "GET",
				async: true,
				headers: {
					"Authorization": "Bearer " + this.ACCESS_TOKEN,
					"Content-Type": "application/json",
					"Accept-Language": "en_EN"
				}
			}).done(function(results){
				$.sap.log.info("get products successfully");
				oModel.setProperty("/data", results.products);
			}).fail(function(xhr, textStatus, errorThrown){
				$.sap.log.error(xhr);
				MessageToast.show("Cannot get Uber Products");
			});
		},
		
		// get available prices 
		getPrices: function(){
			var oData = {
				"sourceLat": "37.7752315",
				"sourceLng": "-122.418075",
				"destinationLat": "37.7752415",
				"destinationLng": "-122.518075",
				"seat_count": "2"
			};
			
			var sUrl = "https://api.uber.com/v1.2/estimates/price?start_latitude=" + 
						oData.sourceLat + 
						"&start_longitude=" + 
						oData.sourceLng +
						"&end_latitude=" +
						oData.destinationLat +
						"&end_longitude=" +
						oData.destinationLng;
			var oModel = this.getView().getModel("prices");
			var that = this;
			
			// call uber api to get estimation
			$.ajax({
				url: sUrl,
				type: "GET",
				async: true,
				headers:{
					"Authorization": "Bearer " + this.ACCESS_TOKEN,
					"Content-Type": "application/json"
				}
			}).done(function(results){
				$.sap.log.info("get estimated prices");
				oModel.setProperty("/data", results);
			}).fail(function(xhr, textStatus, errorThrown){
				$.sap.log.error("xhr");
				MessageToast.show("Cannot get Price Information");
			});
		},
		
		// create a ride request
		onRideRequest: function(oEvent){
			// for test
			var oSampleRequest = {
		        "sourceLat": "37.7752315",
		        "sourceLng": "-122.418075",
		        "destinationLat": "37.7752415",
		        "destinationLng": "-122.518075",
		        "seat_count": "2"
			};
			
			var oTable = this.byId("productTable");
			var selectedIndex = oTable.getSelectedIndex();
			var oModelProduct = this.getView().getModel("product");
			var oModelEstimate = this.getView().getModel("estimate");
			var that = this;
			// get selected product
			if(oModelProduct.getData()){
				var oProduct = oModelProduct.getData().data[selectedIndex];
				var sUrl = "https://api.uber.com/v1.2/requests/estimate";
				// build up the POST data
				var oData = {
					"product_id": oProduct.product_id,
					"start_latitude": oSampleRequest.sourceLat,
					"start_longitude": oSampleRequest.sourceLng,
					"end_latitude": oSampleRequest.destinationLat,
					"end_longitude": oSampleRequest.destinationLng,
					"seat_count": oSampleRequest.seat_count
				};
				// call uber api to request a ride estimation
				$.ajax({
					url: sUrl,
					type: "POST",
					async: true,
					headers: {
						"Authorization": "Bearer " + this.ACCESS_TOKEN,
						"Content-Type": "application/json"
					},
					data: JSON.stringify(oData)
				}).done(function(data){
					$.sap.log.info("Post ride request is successful");
					// update the estimate model
					oModelEstimate.setProperty("/data", data);
					// open the dialog box to display ride estimation data
				//var oDialog = sap.ui.xmlfragment("fareDialog", "sap.bao.fs.xc.uber.controller.RideRequest", this);
					if (that.oDialogRequest){
						that.oDialogRequest.setModel(oModelEstimate, "estimate");
						that.oDialogRequest.open();
					}
				}).fail(function(xhr, textStatus, errorThrown){
					$.sap.log.error("Error during post ride request");
					MessageToast.show("Error during post ride request");
				});
			}
		},
		
		// close dialog box
		onConfirm: function(oEvent){
			// confirm the ride request
			var sUrl = "https://sandbox-api.uber.com/v1.2/requests";	//"https://api.uber.com/v1.2/requests"; for sandbox only
			var modelEstimate = this.getView().getModel("estimate");
			var modelProduct = this.getView().getModel("product");
			var modelStatus = this.getView().getModel("rideStatus");
			var that = this;
			
			// get selected index
			var oTable = this.byId("productTable");
			var selectedIndex = oTable.getSelectedIndex();
			
			var oPostData = {
				"product_id": modelProduct.getData().data[selectedIndex].product_id,
				"start_latitude": this.oSampleProduct.sourceLat,
				"start_longitude": this.oSampleProduct.sourceLng,
				"end_latitude": this.oSampleProduct.destinationLat,
				"end_longitude": this.oSampleProduct.destinationLng,
				"seat_count": this.oSampleProduct.seat_count,
				"fare_id": modelEstimate.getData().data.fare.fare_id
			};
			
			$.ajax({
				url: sUrl,
				type: "POST",
				async: false,
				headers: {
					"Authorization": "Bearer " + this.ACCESS_TOKEN,
					"Content-Type": "application/json"
				},
				data: JSON.stringify(oPostData)
			}).done(function(data, statusText, xhr){
				switch (statusText){
					case "202":	//Accepted
						// Your Request is successfully being processed
						MessageToast.show("Your Request is successfully being processed");
						break;
					case "409": //Conflict
						// An error has occurred, possibly due to no drivers available
						MessageToast.show("An error has occurred, possibly due to no drivers available");
						break;
					case "422":	//Unprocessable Entity
						MessageToast.show("An error has occurred, most likely due to an issue with the user’s Uber account.");
						break;
				}
				modelStatus.setProperty("/data", data);
				
				// update the ETA
				var oText = that.getView().byId("txtETA");
				if (oText){
					oText.setText("In " + data.pickup_estimate + " Minutes");
				}
				$.sap.log.info("Request is processed");
			}).fail(function(xhr, textStatus, errorThrown){
				$.sap.log.info("Error during post ride request");
				// show message
				var oResponseText = JSON.parse(xhr.responseText);
				var sMsg = oResponseText.errors[0].title;
				MessageToast.show(sMsg);
			});
			this.oDialogRequest.close();
		},
		
		onCancel: function(oEvent){
			this.oDialogRequest.close();
		},
		
		onRideStatus: function(oEvent){
			if (!this.oDialogStatus){
				this.oDialogStatus = sap.ui.xmlfragment("dialogStatus", "sap.bao.fs.xc.uber.view.RideStatus", this.getView().getController());
			}
			
			var sUrl = "https://api.uber.com/v1.2/requests/current";
			var oModel = this.getView().getModel("status");
			
			// call uber api to get current trip information
			$.ajax({
				url: sUrl,
				type: "GET",
				async: true,
				headers: {
					"Authorization": "Bearer " + this.ACCESS_TOKEN
				}
			}).done(function(data, statusText, xhr){
				oModel.setProperty("/data", data);
				this.oDialogStatus.setModel(oModel, "status");
				this.oDialogStatus.open();
			}).fail(function(xhr, statusText, errorThrown){
				MessageToast.show("User is not currently on a trip");
			});
			
			
		}
	});
});